import requests

url = f"https://api.thingspeak.com/channels/2402314/feeds.json?api_key=CNH9RJ7BH9DC9T33&results=1"

# Send HTTP GET request to ThingSpeak
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    data = response.json()
    
    # Extract and print the latest entry
    if 'feeds' in data and len(data['feeds']) > 0:
        latest_entry = data['feeds'][0]
        print("Latest entry:")
 
        print("Secret message:", latest_entry['field1'])
        print("Password:", latest_entry['field2'])
       
        # Add more fields as needed
    else:
        print("No data available in the channel.")
else:
    print(f"Failed to fetch data. Status code: {response.status_code}")
    print(response.text)
