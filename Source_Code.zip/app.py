from flask import Flask,request
from flask import render_template,url_for

from sender import hideFunc
from receiver import revealFunc
import requests
api_key = "71T2VPKNTVPEU684"
channel_id = "2402314"
url = f"https://api.thingspeak.com/update?api_key={api_key}"
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("homepage.html")

@app.route("/hide",methods=['POST','GET'])
def hide():
    if request.method == 'POST':
        formInfo=request.form
        result=hideFunc(formInfo['sec_msg'],formInfo['psw'],formInfo['cvr_msg'])
        passs=formInfo['psw']
        msg=formInfo['cvr_msg']
        data = {'field1': msg, 'field2': passs}
        # url = f"https://api.thingspeak.com/update?api_key=71T2VPKNTVPEU684&field1="+passs
        response = requests.post(url, data)

        return render_template("homepage.html",result=result)
    return render_template("homepage.html")

@app.route("/reveal",methods=['POST','GET'])
def reveal():
    if request.method == 'POST':
        formInfo=request.form
        result_reveal=revealFunc(formInfo['steg_msg'],formInfo['psw_rev'])
        return render_template("homepage.html",result_reveal=result_reveal)
    return render_template("homepage.html")


if __name__=='__main__':
    app.run(debug=True)

# set FLASK_ENV=development
# set FLASK_APP=app.py